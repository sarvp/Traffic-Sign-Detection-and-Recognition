import cv2
import sys
import argparse
x = 0
y = 0
cascPath = "Pedesrtian Crossing.xml "
faceCascade = cv2.CascadeClassifier('C:\opencv\opencv\sources\data\haarcascades\Pedesrtian Crossing.xml')
cascPath = "haarcascade_fullbody.xml "
FullBody = cv2.CascadeClassifier('C:\opencv\opencv\sources\data\haarcascades\haarcascade_fullbody.xml')
cascPath = "haarcascade_lowerbody.xml "
LowerBody = cv2.CascadeClassifier('C:\opencv\opencv\sources\data\haarcascades\haarcascade_lowerbody.xml')
cascPath = "haarcascade_fullbody.xml "
UpperBody = cv2.CascadeClassifier('C:\opencv\opencv\sources\data\haarcascades\haarcascade_upperbody.xml')

hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
font = cv2.FONT_HERSHEY_SIMPLEX
video_capture = cv2.VideoCapture(0)
while True :
    ret, frame = video_capture.read()

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    (rects, weights) = hog.detectMultiScale(gray,
                                            winStride=(4,4),
	                                    padding=(8,8),
                                            scale=1.5)
   

    for(x,y,w,h) in rects:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),3)
            stringxy="+%s,%s"%(x,y)
            cv2.putText(frame,"Pedestrian!!!",(x+w/2,y+h/2),font,1,(0,255,0),2)
            print "pedistrian!!!"
            print "\n"


    FB = FullBody.detectMultiScale(
        gray,
        scaleFactor = 1.1,
        minNeighbors=5,
        minSize=(50,50),
        flags = cv2.CASCADE_SCALE_IMAGE
        )
       

    for(x,y,w,h) in FB:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),2)
            stringxy="Pedestrian!!!"
            cv2.putText(frame,stringxy,(x+w/2,y+h/2),font,1,(0,255,0),2)
            
    LB = LowerBody.detectMultiScale(
        gray,
        scaleFactor = 1.1,
        minNeighbors=5,
        minSize=(50,50),
        flags = cv2.CASCADE_SCALE_IMAGE
        )
       

    for(x,y,w,h) in LB:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),2)
            stringxy="Pedestrian!!!"
            cv2.putText(frame,stringxy,(x+w/2,y+h/2),font,1,(0,255,0),2)

    UB = UpperBody.detectMultiScale(
        gray,
        scaleFactor = 1.1,
        minNeighbors=5,
        minSize=(50,50),
        flags = cv2.CASCADE_SCALE_IMAGE
        )
       

    for(x,y,w,h) in UB:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),2)
            stringxy="Pedestrian!!!"
            cv2.putText(frame,stringxy,(x+w/2,y+h/2),font,1,(0,255,0),2)        
    cv2.imshow('Video',frame)
    print x,y
    print "\n"

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

            
    cv2.imshow('Video',frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
video_capture.release()
cv2.destroyAllWindows()

