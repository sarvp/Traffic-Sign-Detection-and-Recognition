import cv2
import sys
x = 0
y = 0

cascPathnsNE = "No Entry Final.xml "
NoEntry = cv2.CascadeClassifier('C:\Users\Pinto Electronic\kpit\Working\NE.xml')
cascPathnsOW = "One Way Working.xml "
OneWay = cv2.CascadeClassifier('C:\Users\Pinto Electronic\kpit\Working\One Way 5.xml')
cascPathnsNR = "No Right.xml "
NoRight = cv2.CascadeClassifier('C:\Users\Pinto Electronic\kpit\Working\No Right.xml')
cascPathnsPC = "mystop_working.xml "
Stop = cv2.CascadeClassifier('C:\Users\Pinto Electronic\kpit\Working\mystop_working.xml')
cascPathnsW = "Workers Working.xml "
Workers = cv2.CascadeClassifier('C:\Users\Pinto Electronic\kpit\Working\Workers Working Perfect.xml')
cascPathnsSL15 = "SL15 1.xml "
SpeedLimit15 = cv2.CascadeClassifier('C:\Users\Pinto Electronic\kpit\Working\SL15 1.xml')
cascPathnsNL = "No Left Final.xml "
NoLeft = cv2.CascadeClassifier('C:\Users\Pinto Electronic\kpit\Working\NL1 Working.xml')
cascPathnsNU = "No U Turn Working.xml "
NoUTurn = cv2.CascadeClassifier('C:\Users\Pinto Electronic\kpit\Working\No U Turn Working.xml')
cascPathnsSB = "SB.xml "
SpeedBreaker = cv2.CascadeClassifier('C:\Users\Pinto Electronic\kpit\Working\Speed Breaker.xml')
font = cv2.FONT_HERSHEY_SIMPLEX
#video_capture = cv2.VideoCapture("C:\Users\Sarv\Desktop\VIDEO0100.mp4")
video_capture = cv2.VideoCapture(1)

while True :
    ret, frame = video_capture.read()

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    speedlimit = SpeedLimit15.detectMultiScale(
        gray,
        scaleFactor = 1.1,
        minNeighbors=5,
        minSize=(50,50),
        flags = cv2.CASCADE_SCALE_IMAGE
        )
   

    for(x,y,w,h) in speedlimit:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),3)
            stringxy="+%s,%s"%(x,y)
            cv2.putText(frame,"Speed Limit 15 KMPH!!!",(x+w/2,y+h/2),font,1,(0,255,0),2)
            print "Speed Limit 15 KMPH !!!" 
            print "\n"
            


    noentry = NoEntry.detectMultiScale(
        gray,
        scaleFactor = 1.1,
        minNeighbors=5,
        minSize=(50,50),
        flags = cv2.CASCADE_SCALE_IMAGE
        )
   

    for(x,y,w,h) in noentry:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),3)
            stringxy="+%s,%s"%(x,y)
            cv2.putText(frame,"No Entry!!!",(x+w/2,y+h/2),font,1,(0,255,0),2)
            print "No Entry!!!" 
            print "\n"

    oneway = OneWay.detectMultiScale(
        gray,
        scaleFactor = 1.1,
        minNeighbors=5,
        minSize=(50,50),
        flags = cv2.CASCADE_SCALE_IMAGE
        )
   

    for(x,y,w,h) in oneway:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),3)
            stringxy="+%s,%s"%(x,y)
            cv2.putText(frame,"One Way !!!",(x+w/2,y+h/2),font,1,(0,255,0),2)
            print "!!!!!! One Way !!!!!!" 
            print "\n"        


    noright = NoRight.detectMultiScale(
        gray,
        scaleFactor = 1.1,
        minNeighbors=5,
        minSize=(50,50),
        flags = cv2.CASCADE_SCALE_IMAGE
        )
   

    for(x,y,w,h) in noright:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),3)
            stringxy="+%s,%s"%(x,y)
            cv2.putText(frame,"No Right Turn",(x+w/2,y+h/2),font,1,(0,255,0),2)
            print "!!!!!! No Right Turn !!!!!!" 
            print "\n"


    stop = Stop.detectMultiScale(
        gray,
        scaleFactor = 1.1,
        minNeighbors=5,
        minSize=(50,50),
        flags = cv2.CASCADE_SCALE_IMAGE
        )
   

    for(x,y,w,h) in stop:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),3)
            stringxy="+%s,%s"%(x,y)
            cv2.putText(frame,"Stop!!!",(x+w/2,y+h/2),font,1,(0,255,0),2)
            print "!!!!!! Stop !!!!!!" 
            print "\n"


    workers = Workers.detectMultiScale(
        gray,
        scaleFactor = 1.1,
        minNeighbors=5,
        minSize=(50,50),
        flags = cv2.CASCADE_SCALE_IMAGE
        )
   

    for(x,y,w,h) in workers:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),3)
            stringxy="+%s,%s"%(x,y)
            cv2.putText(frame,"Workers Working",(x+w/2,y+h/2),font,1,(0,255,0),2)
            print "!!!!!! Workers Working !!!!!!" 
            print "\n"
            
    noleft = NoLeft.detectMultiScale(
        gray,
        scaleFactor = 1.1,
        minNeighbors=5,
        minSize=(50,50),
        flags = cv2.CASCADE_SCALE_IMAGE
        )
   

    for(x,y,w,h) in noleft:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),3)
            stringxy="+%s,%s"%(x,y)
            cv2.putText(frame,"No Left Turn",(x+w/2,y+h/2),font,1,(0,255,0),2)
            print "!!!!!! No Left Turn !!!!!!" 
            print "\n"

    speedbreaker = SpeedBreaker.detectMultiScale(
        gray,
        scaleFactor = 1.1,
        minNeighbors=5,
        minSize=(50,50),
        flags = cv2.CASCADE_SCALE_IMAGE
        )
   

    for(x,y,w,h) in speedbreaker:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),3)
            stringxy="+%s,%s"%(x,y)
            cv2.putText(frame,"Speed Breaker!!!",(x+w/2,y+h/2),font,1,(0,255,0),2)
            print "Speed Breaker Ahead !!!" 
            print "\n"

    nouturn = NoUTurn.detectMultiScale(
        gray,
        scaleFactor = 1.1,
        minNeighbors=5,
        minSize=(50,50),
        flags = cv2.CASCADE_SCALE_IMAGE
        )
   

    for(x,y,w,h) in nouturn:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,100),3)
            stringxy="+%s,%s"%(x,y)
            cv2.putText(frame,"No U Turn!!!",(x+w/2,y+h/2),font,1,(0,255,0),2)
            print "No U Turn !!!" 
            print "\n"            
            
    cv2.imshow('Video',frame)
    

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

video_capture.release()
cv2.destroyAllWindows()
